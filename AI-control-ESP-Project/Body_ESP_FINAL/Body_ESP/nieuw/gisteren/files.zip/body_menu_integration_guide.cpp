/*
  ═══════════════════════════════════════════════════════════════════════════
  HOE ALLES IN BODY_MENU.CPP GEKOPPELD WORDT
  ═══════════════════════════════════════════════════════════════════════════
  
  Dit bestand toont EXACT welke code je waar moet toevoegen in body_menu.cpp
*/

// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 1: INCLUDES (bovenaan body_menu.cpp)
// ═══════════════════════════════════════════════════════════════════════════

#include "ml_integration.h"    // Dit koppelt alles aan elkaar!
// ml_integration.h includeert automatisch:
//   - ml_training.h
//   - ml_annotation.h  
//   - ml_stress_analyzer.h
//   - ai_bijbel.h
//   - playback_screen_v2.h


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 2: IN bodyMenuSetup() of setup()
// ═══════════════════════════════════════════════════════════════════════════

void bodyMenuSetup() {
  // ... bestaande setup code ...
  
  // 🔥 NIEUW: Initialize ML Integration
  mlIntegration_begin();
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 3: IN bodyMenuTick() of loop()
// ═══════════════════════════════════════════════════════════════════════════

void bodyMenuTick() {
  // ... bestaande tick code ...
  
  // 🔥 NIEUW: Update sensors naar ML systeem (alleen tijdens live sessie)
  if (mlState.liveSessionActive) {
    // currentBPM, currentTemp, currentGSR zijn je bestaande sensor variabelen
    mlIntegration_updateSensors(currentBPM, currentTemp, currentGSR);
  }
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 4: RECORDING START/STOP
// ═══════════════════════════════════════════════════════════════════════════

void startRecording() {
  // ... bestaande recording start code ...
  
  // 🔥 NIEUW: Start ML training sessie
  mlIntegration_startLiveSession();
}

void stopRecording() {
  // ... bestaande recording stop code ...
  
  // 🔥 NIEUW: Stop ML training sessie
  mlIntegration_stopLiveSession();
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 5: ESP-NOW NUNCHUK HANDLER
// ═══════════════════════════════════════════════════════════════════════════

// In je ESP-NOW callback wanneer nunchuk een level wijzigt:
void onNunchukLevelChange(int newLevel) {
  int currentAILevel = mlState.currentStressLevel;  // Wat AI had gekozen
  
  if (newLevel != currentAILevel) {
    // 🔥 NIEUW: Log correctie naar ML
    mlIntegration_logNunchukCorrection(currentAILevel, newLevel);
  }
  
  // Pas level aan (bestaande code)
  // setKeonLevel(newLevel);
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 6: PLAYBACK START/STOP
// ═══════════════════════════════════════════════════════════════════════════

void startPlayback(const char* filename) {
  // ... bestaande playback start code ...
  
  // 🔥 NIEUW: Start ML playback modus
  mlIntegration_startPlayback(filename);
}

void stopPlayback() {
  // 🔥 NIEUW: Stop ML playback (slaat annotaties op!)
  mlIntegration_stopPlayback();
  
  // ... bestaande playback stop code ...
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 7: PLAYBACK UPDATE (bij elke regel)
// ═══════════════════════════════════════════════════════════════════════════

void updatePlayback() {
  // Parse CSV regel (bestaande code)
  // float hr = ...
  // float temp = ...
  // float gsr = ...
  // float timestamp = ...
  
  // Check voor StressLevel kolom (uit .anl bestand)
  int aiLevel = -1;
  if (hasStressLevelColumn) {
    aiLevel = parseStressLevel(line);
  }
  
  // 🔥 NIEUW: Update ML playback state
  mlIntegration_updatePlayback(timestamp, hr, temp, gsr, aiLevel);
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 8: GEVOEL KNOP HANDLER
// ═══════════════════════════════════════════════════════════════════════════

// In de touch handler voor GEVOEL popup OPSLAAN knop:
void onGevoelSave(int selectedLevel) {
  // 🔥 NIEUW: Log feedback via ML integration
  mlIntegration_logGevoelFeedback(selectedLevel);
  
  // Sluit popup (bestaande code)
  stressPopupActive = false;
}

// Bij openen van GEVOEL popup:
void onGevoelOpen() {
  stressPopupActive = true;
  
  // 🔥 NIEUW: Check of er al een annotatie is
  int existing = mlIntegration_getExistingFeedback();
  if (existing >= 0) {
    selectedStressLevel = existing;  // Laad bestaande waarde
  } else if (mlState.aiPredictedLevel >= 0) {
    selectedStressLevel = mlState.aiPredictedLevel;  // AI voorspelling als start
  } else {
    selectedStressLevel = mlState.currentStressLevel;  // Bereken level
  }
}


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 9: AI TRAINING MENU - "Feedback" KNOP
// ═══════════════════════════════════════════════════════════════════════════

// In ML Training menu touch handler:
case 2:  // "Feedback" knop
  // Open Recording menu zodat gebruiker een bestand kan kiezen
  // voor playback met annotatie modus
  bodyMenuPage = BODY_PAGE_RECORDING;
  recordingMenuMode = RECORDING_MODE_PLAYBACK;  // Speciale modus
  Serial.println("[ML TRAINING] Feedback - kies een bestand om te beoordelen");
  break;


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 10: AI TRAINING MENU - "Model Trainen" KNOP
// ═══════════════════════════════════════════════════════════════════════════

case 1:  // "Model Trainen" knop
  Serial.println("[ML TRAINING] Starting model training...");
  
  // Toon "Training..." op scherm
  body_gfx->fillRect(MENU_X, MENU_Y, MENU_W, MENU_H, 0x0000);
  body_gfx->setTextColor(0xFFFF);
  body_gfx->setCursor(MENU_X + 50, MENU_Y + 100);
  body_gfx->print("Training model...");
  body_gfx->setCursor(MENU_X + 50, MENU_Y + 130);
  body_gfx->print("Even geduld...");
  
  // 🔥 NIEUW: Train model
  if (mlIntegration_trainModel()) {
    // Success!
    body_gfx->fillRect(MENU_X, MENU_Y, MENU_W, MENU_H, 0x0000);
    body_gfx->setTextColor(0x07E0);  // Groen
    body_gfx->setCursor(MENU_X + 50, MENU_Y + 100);
    body_gfx->print("Training GELUKT!");
    body_gfx->setCursor(MENU_X + 50, MENU_Y + 130);
    body_gfx->printf("Accuracy: %.0f%%", mlState.modelAccuracy * 100);
  } else {
    // Failed
    body_gfx->fillRect(MENU_X, MENU_Y, MENU_W, MENU_H, 0x0000);
    body_gfx->setTextColor(0xF800);  // Rood
    body_gfx->setCursor(MENU_X + 50, MENU_Y + 100);
    body_gfx->print("Training MISLUKT");
    body_gfx->setCursor(MENU_X + 50, MENU_Y + 130);
    body_gfx->print("Meer feedback nodig!");
  }
  
  delay(2000);  // Toon resultaat even
  menuDirty = true;
  break;


// ═══════════════════════════════════════════════════════════════════════════
//                    STAP 11: AI BESLISSINGEN IN MAIN LOOP
// ═══════════════════════════════════════════════════════════════════════════

// Wanneer AI een actie moet nemen (in je control loop):
void aiControlLoop() {
  extern uint8_t aiAutonomy;  // 0-100%
  
  // 🔥 NIEUW: Krijg optimaal level via ML integration
  int optimalLevel = mlIntegration_getOptimalLevel(aiAutonomy);
  
  // Check of AI naar dit level mag
  if (mlIntegration_aiMagNaarLevel(aiAutonomy, optimalLevel)) {
    // Voer actie uit
    setKeonLevel(optimalLevel);
    mlState.aiPredictedLevel = optimalLevel;
  }
}


// ═══════════════════════════════════════════════════════════════════════════
//                    SAMENVATTING - ALLE FUNCTIES
// ═══════════════════════════════════════════════════════════════════════════

/*
INITIALISATIE:
  mlIntegration_begin()                     - In setup()

LIVE SESSIE:
  mlIntegration_startLiveSession()          - Bij recording start
  mlIntegration_stopLiveSession()           - Bij recording stop
  mlIntegration_updateSensors(hr,t,gsr)     - Elke loop
  mlIntegration_logNunchukCorrection(ai,u)  - Bij nunchuk override
  mlIntegration_logEdge()                   - Bij edge detectie
  mlIntegration_logOrgasme()                - Bij orgasme

PLAYBACK:
  mlIntegration_startPlayback(filename)     - Bij playback start
  mlIntegration_stopPlayback()              - Bij playback stop
  mlIntegration_updatePlayback(t,hr,t,g,ai) - Bij elke regel
  mlIntegration_logGevoelFeedback(level)    - Bij GEVOEL opslaan
  mlIntegration_getExistingFeedback()       - Check bestaande annotatie

AI BESLISSINGEN:
  mlIntegration_getOptimalLevel(autonomy%)  - Krijg beste level
  mlIntegration_aiMagNaarLevel(a%,level)    - Check permissie

TRAINING:
  mlIntegration_trainModel()                - Train neural network
  mlIntegration_getStats(...)               - Krijg statistieken
*/


// ═══════════════════════════════════════════════════════════════════════════
//                    FLOW DIAGRAM
// ═══════════════════════════════════════════════════════════════════════════

/*
                    ┌─────────────────────────────────────┐
                    │            SETUP                     │
                    │    mlIntegration_begin()            │
                    └──────────────┬──────────────────────┘
                                   │
                    ┌──────────────┴──────────────────────┐
                    │                                      │
          ┌─────────▼─────────┐              ┌────────────▼────────────┐
          │   LIVE SESSIE     │              │      PLAYBACK           │
          │   ─────────────   │              │      ────────           │
          │                   │              │                          │
          │ startLiveSession()│              │ startPlayback(file)     │
          │        │          │              │         │                │
          │        ▼          │              │         ▼                │
          │ ┌─────────────┐   │              │  ┌─────────────┐        │
          │ │ updateSensors│◄─┤─── loop ────►├──│updatePlayback│       │
          │ └─────────────┘   │              │  └─────────────┘        │
          │        │          │              │         │                │
          │        ▼          │              │         ▼                │
          │ Nunchuk override? │              │  GEVOEL knop?           │
          │        │          │              │         │                │
          │   YES  │          │              │    YES  │                │
          │        ▼          │              │         ▼                │
          │ logNunchukCorrect │              │ logGevoelFeedback       │
          │        │          │              │         │                │
          │        ▼          │              │         ▼                │
          │    Edge?          │              │                          │
          │        │          │              │                          │
          │   YES  │          │              │                          │
          │        ▼          │              │                          │
          │    logEdge()      │              │                          │
          │        │          │              │         │                │
          │        ▼          │              │         ▼                │
          │ stopLiveSession() │              │   stopPlayback()        │
          └─────────┬─────────┘              └──────────┬──────────────┘
                    │                                    │
                    │      ┌─────────────────────┐       │
                    └─────►│    feedback.csv     │◄──────┘
                           │    sessie.ann       │
                           └──────────┬──────────┘
                                      │
                           ┌──────────▼──────────┐
                           │   Model Trainen     │
                           │  mlIntegration_     │
                           │    trainModel()     │
                           └──────────┬──────────┘
                                      │
                           ┌──────────▼──────────┐
                           │     model.bin       │
                           └──────────┬──────────┘
                                      │
                           ┌──────────▼──────────┐
                           │  AI gebruikt ML!    │
                           │ getOptimalLevel()   │
                           └─────────────────────┘
*/
